from flask import Flask, render_template,request,session,logging,url_for,redirect,flash
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from passlib.hash import sha256_crypt

##for json##
import os
from flask import json
##end##

engine = create_engine('mysql://root:1234567890@localhost/finalyear')
                        #('mysql://username:password@localhost/databasename')
db=scoped_session(sessionmaker(bind=engine))

app=Flask(__name__)

@app.route('/index', methods=["GET","POST"])
def home():
    if request.method=='POST':
        username = request.form.get('username')
        password = request.form.get('password')

        usernamedata = db.execute("SELECT username FROM users WHERE username=:username",{"username":username}).fetchone()
        passworddata = db.execute("SELECT password FROM users WHERE username=:username",{"username":username}).fetchone()

        if usernamedata is None:
            flash("Invalid Username")
            return render_template("index.html")
        else:
            for password_data in passworddata:
                if sha256_crypt.verify(password,password_data):
                    flash("You have now logged in")
                    return redirect(url_for('dashboard'))
                else:
                    flash('Incorrect password')
                    return render_template('index.html')

    return render_template('index.html')

#register form
@app.route('/register', methods=["GET","POST"])
def register():
    if request.method=='POST':
        Fname = request.form.get("Fname")
        Lname = request.form.get("Lname")
        username = request.form.get('username')
        password = request.form.get('password')
        confirm = request.form.get('confirm')
        secure_password = sha256_crypt.encrypt(str(password))

        if password == confirm:
            db.execute("INSERT INTO users(Fname, Lname, username, password) VALUES (:Fname,:Lname,:username, :password)",
                                          {'Fname':Fname,'Lname':Lname,'username':username,'password':secure_password})
        
            db.commit()
            flash("You have successfully registered",'success')
            return redirect(url_for('home'))
        else:
            flash("Password does not match")
            return render_template("register.html")

    return render_template('register.html')

# for dashboard
@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

#logout
@app.route('/logout')
def logout():
    session.clear()
    flash("You have successfully logged out")
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.secret_key="Herald54321@##"
    app.run(debug=True)
